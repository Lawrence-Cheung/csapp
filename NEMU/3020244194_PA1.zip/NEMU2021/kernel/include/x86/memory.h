#ifndef __X86_MEMORY_H__
#define __X86_MEMORY_H__

#include "x86-inc/mmu.h"

#endif
