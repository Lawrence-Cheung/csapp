#ifndef __WATCHPOINT_H__
#define __WATCHPOINT_H__

#include "common.h"

typedef struct watchpoint {
	int NO;
	struct watchpoint *next;
	char expr[32];
	uint32_t value;
	/* TODO: Add more members if necessary */


} WP;

extern void new_wp(char*,uint32_t);
extern void print_wp();
extern bool check_wp();
extern void free_wp(int);

#endif
