#include "monitor/watchpoint.h"
#include "monitor/expr.h"
#include "cpu/reg.h"


#define NR_WP 64

static WP wp_pool[NR_WP];
static WP *head, *free_;

void init_wp_pool() {
	int i;
	for(i = 0; i < NR_WP; i ++) {
		wp_pool[i].NO = i;
		wp_pool[i].next = &wp_pool[i + 1];
	}
	wp_pool[NR_WP - 1].next = NULL;

	head = NULL;
	free_ = wp_pool;
}

/* TODO: Implement the functionality of watchpoint */
void new_wp(char *expr, uint32_t value)
{
 if (free_)
 {
  WP *tmp = free_;
  free_ = tmp->next;
  tmp->next = NULL;
  strcpy(tmp->expr, expr);
  tmp->value = value;

  if (head == NULL)
  {
   head = tmp;
   tmp->NO = 1;
  }
  else
  {
   WP *p = head;
   while (p->next)
    p = p->next;
   p->next = tmp;
   tmp->NO = p->NO + 1;
  }
  printf("Watchpoint %d: %s\n", tmp->NO, tmp->expr);
 }
 else
  printf("No free watchpoints.\n");
}

void free_wp(int wp_NO)
{
 if (head == NULL)
 {
  printf("Input something.\n");
  return;
 }
 WP *wp = head;
 WP *wp_previous = NULL;
 int i;
 for (i = 1; wp->next && i < wp_NO; i++)
 {
  wp = wp->next;
  wp_previous = wp;
 }
 if (i != wp_NO)
 {
  printf("No watchpoint number %d\n", wp_NO);
  return;
 }

 if (wp_previous == NULL)
  head = wp->next;
 else
  wp_previous->next = wp->next;

 WP *p = wp->next;
 while (p)
 {
  (p->NO)--;
  p = p->next;
 }
 wp->next = free_;
 free_ = wp;
}

bool check_wp()
{
 bool changed = false;
 WP *p = head;
 while (p != NULL)
 {
  bool success = true;
  uint32_t ans = expr(p->expr, &success);
  if (ans != p->value)
  {
   printf("\nHint watchpoint %d at address 0x%08x, expr = %s\n", p->NO, cpu.eip, p->expr);
   changed = true;
   printf("old value = %d\new value = %d\n", p->value, ans);
   p->value = ans;
  }
  p = p->next;
 }
 return changed;
}

void print_wp()
{
 if (head == NULL)
 {
  printf("No watchpoints.\n");
  return;
 }
 printf("Num\tExpr\tVal\n");
 WP *p = head;
 while (p != NULL)
 {
  printf("%d\t%s\t%d\n", p->NO, p->expr, p->value);
  p = p->next;
 }
}

