#ifndef __JMP_H__
#define __JMP_H__

make_helper(jmp_si_b);
make_helper(jmp_si_l);

make_helper(jmp_rm_l);

#endif
