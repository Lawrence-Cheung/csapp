#ifndef __INC_H__
#define __INC_H__

make_helper(inc_rm_b);

make_helper(inc_rm_v);
make_helper(inc_r_v);

#endif
