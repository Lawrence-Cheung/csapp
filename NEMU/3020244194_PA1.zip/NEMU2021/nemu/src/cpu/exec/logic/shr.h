#ifndef __SHR_H__
#define __SHR_H__

make_helper(shr_rm_1_b);
make_helper(shr_rm_cl_b);
make_helper(shr_rm_imm_b);

make_helper(shr_rm_1_v);
make_helper(shr_rm_cl_v);
make_helper(shr_rm_imm_v);
#endif
