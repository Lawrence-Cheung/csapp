#ifndef __SHRD_H__
#define __SHRD_H__

make_helper(shrdi_v);

#endif
