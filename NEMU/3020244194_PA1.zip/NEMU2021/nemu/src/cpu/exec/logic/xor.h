#ifndef __XOR_H__
#define __XOR_H__

make_helper(xor_i2a_b);
make_helper(xor_i2rm_b);
make_helper(xor_r2rm_b);
make_helper(xor_rm2r_b);

make_helper(xor_i2a_v);
make_helper(xor_i2rm_v);
make_helper(xor_si2rm_v);
make_helper(xor_r2rm_v);
make_helper(xor_rm2r_v);

#endif
