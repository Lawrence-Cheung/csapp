#ifndef __STOS_H__
#define __STOS_H__

make_helper(stos_b);

make_helper(stos_v);

#endif
